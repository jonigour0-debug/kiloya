KILOYA 10 LEVEL UPDATE

Files:
- menu.html: character select and all 10 level buttons
- game.html: one reusable playable platform game; level number is passed in the URL
- assets/: five supplied character portraits

How to install:
1. Extract this ZIP.
2. Open your GitHub repository.
3. Upload and replace menu.html.
4. Upload game.html.
5. Upload the assets folder with all portrait images.
6. Commit changes.
7. Open your GitHub Pages website and visit /menu.html.

The existing index.html and level2.html are kept in your repository and are not deleted.
The new menu launches game.html?level=1 through game.html?level=10.
Controls: A/D or arrow keys to move; SPACE/W/UP to jump. On mobile, use the on-screen buttons.
